#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
import serial

ser = serial.Serial('/dev/ttyUSB1', 115200)

WHEEL_BASE = 0.20
MAX_PWM = 150   # keep safe

def cmd_callback(msg):
    v = msg.linear.x
    w = msg.angular.z

    left  = v - (w * WHEEL_BASE / 2.0)
    right = v + (w * WHEEL_BASE / 2.0)

    left_pwm  = int(max(min(left * 255, MAX_PWM), -MAX_PWM))
    right_pwm = int(max(min(right * 255, MAX_PWM), -MAX_PWM))

    cmd = "<%d,%d>\n" % (left_pwm, right_pwm)

    print("Sending:", cmd)   #  DEBUG
    ser.write(cmd)

def main():
    rospy.init_node('serial_bridge')
    rospy.Subscriber('/cmd_vel', Twist, cmd_callback)
    rospy.spin()

if __name__ == '__main__':
    main()
