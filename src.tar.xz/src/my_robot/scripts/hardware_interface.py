#!/usr/bin/env python
import rospy
import serial
import math
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import tf

class HardwareInterface:
    def __init__(self):
        rospy.init_node('hardware_interface')
        self.port = rospy.get_param("~port", "/dev/ttyUSB1")
        self.baud = rospy.get_param("~baud", 115200)
        self.wheel_radius = 0.05
        self.wheel_base = 0.20
        self.ticks_per_rev = 600
        self.ser = serial.Serial(self.port, self.baud, timeout=1)
        rospy.Subscriber("/cmd_vel", Twist, self.cmd_callback)
        self.odom_pub = rospy.Publisher("/odom", Odometry, queue_size=10)
        self.br = tf.TransformBroadcaster()
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.last_time = rospy.Time.now()

    def cmd_callback(self, msg):
        v = msg.linear.x
        w = msg.angular.z
        v_l = v - (w * self.wheel_base / 2.0)
        v_r = v + (w * self.wheel_base / 2.0)
        rpm_l = (v_l / (2 * math.pi * self.wheel_radius)) * 60
        rpm_r = (v_r / (2 * math.pi * self.wheel_radius)) * 60
        cmd = "{},{}\n".format(rpm_l, rpm_r)
        self.ser.write(cmd.encode())

    def read_encoders(self):
        if self.ser.in_waiting:
            line = self.ser.readline().decode().strip()
            try:
                left_ticks, right_ticks = map(int, line.split(","))
                return left_ticks, right_ticks
            except:
                return None
        return None

    def update_odometry(self, left_ticks, right_ticks):
        current_time = rospy.Time.now()
        dt = (current_time - self.last_time).to_sec()
        if dt <= 0:
            self.last_time = current_time
            return
        dist_per_tick = (2 * math.pi * self.wheel_radius) / self.ticks_per_rev
        d_l = left_ticks * dist_per_tick
        d_r = right_ticks * dist_per_tick
        d_center = (d_l + d_r) / 2.0
        d_theta = (d_r - d_l) / self.wheel_base
        self.x += d_center * math.cos(self.theta + d_theta / 2.0)
        self.y += d_center * math.sin(self.theta + d_theta / 2.0)
        self.theta += d_theta
        self.publish_odom(d_center / dt, d_theta / dt, current_time)
        self.last_time = current_time

    def publish_odom(self, v, w, current_time):
        quat = tf.transformations.quaternion_from_euler(0, 0, self.theta)

        # --- FIX 1: Broadcast odom -> base_footprint (not base_link) ---
        self.br.sendTransform(
            (self.x, self.y, 0),
            quat,
            current_time,
            "base_footprint",   # CHANGED from base_link
            "odom"
        )

        odom = Odometry()
        odom.header.stamp = current_time
        odom.header.frame_id = "odom"
        odom.child_frame_id = "base_footprint"  # CHANGED from base_link
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.orientation.x = quat[0]
        odom.pose.pose.orientation.y = quat[1]
        odom.pose.pose.orientation.z = quat[2]
        odom.pose.pose.orientation.w = quat[3]
        odom.twist.twist.linear.x = v
        odom.twist.twist.angular.z = w
        self.odom_pub.publish(odom)

    def run(self):
        rate = rospy.Rate(30)
        while not rospy.is_shutdown():
            data = self.read_encoders()
            if data:
                self.update_odometry(data[0], data[1])
            rate.sleep()

if __name__ == "__main__":
    node = HardwareInterface()
    node.run()
